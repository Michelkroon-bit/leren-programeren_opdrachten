for x in range(2):
    if x == 0:
        a= ("am")
    elif x == 1:
        a= ("pm")
    for h in range(1, 13):
        print(f"{h}{a}")