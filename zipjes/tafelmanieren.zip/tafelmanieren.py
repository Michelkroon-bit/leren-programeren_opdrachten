#for loop
tafel_input = int(input("vul een getal tot 10 in "))
for x in range(1 , 11):
    #calc
    answ = x * tafel_input
    print(f"{x} x {tafel_input} = {answ}")