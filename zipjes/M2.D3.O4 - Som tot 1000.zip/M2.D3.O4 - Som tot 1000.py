begin = 50
optel=begin+1
uitkomst = begin + optel 
print(uitkomst)
while uitkomst <= 1000:
    uitkomst = uitkomst + optel
    print(uitkomst)
    optel += 1