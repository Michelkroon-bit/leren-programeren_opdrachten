from studieadviestext import * 
print('voor de volgende vragen kun je de antwoorden "Kies 0: altijd; 1: vaak; 2: regelmatig; 3: soms; 4: nooit"')
antwoord_1=int(input(COMPETENTIE_STELLING_1 ))

antwoord_2=int(input(COMPETENTIE_STELLING_2))

antwoord_3 = int(input(COMPETENTIE_STELLING_3))

antwoord_4 = int(input(COMPETENTIE_STELLING_4))

antwoord_5 = int(input(COMPETENTIE_STELLING_5))

antwoord_6 = int(input(COMPETENTIE_STELLING_6))

antwoord_7 = int(input(COMPETENTIE_STELLING_7))

uitkomst = antwoord_1+antwoord_2+antwoord_3+antwoord_4+antwoord_5+antwoord_6+antwoord_7
uitkomst_1=uitkomst/7
print (uitkomst) #for debugging

if uitkomst == '3':
    print('Advies is twijfelachtig')
    
if uitkomst == '2':
    print('Advies is zorgelijk')

if uitkomst == '1':
    print('Advies is zorgelijk')


else:
    print('Advies is geruststellend')