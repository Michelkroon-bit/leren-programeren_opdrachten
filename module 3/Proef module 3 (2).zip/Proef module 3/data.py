BEDANKT_EN_TOT_ZIENS = 'Bedankt en tot ziens'
SORRY_IK_BEGRIJP_HET_NIET = 'Sorry ik begrijp het niet'
U_MOET_WEL_EEN_GETAL_BOVEN_DE_0_INVOEREN = 'U moet wel een getal boven de 0 invoeren'
SORRY_ZULKE_GROOTTE_BAKJES_VERKOPEN_WIJ_NIET = 'Sorry , zulke grote bakken hebben we niet'
MAX_LENGTH = 12
PRIJS_PER_LITER = 9.80
PRIJS_PER_BOLLETJES = 1.10
HOORNTJE = 1.25
BAKJES = 0.75

SLAGROOM = 0.50
SPRINKELS = 0.30 #Voor ieder bolletje dus sprinkels * bolletje 
CARAMEL_SAUS_IN_BAKJE = 0.60
CARAMEL_SAUS_IN_HOORNTJE = 0.90


bestellingen_lijst = []

bestelling_count = 0
bestelling_string = f'bestelling {bestelling_count}'
bestelling = {}
