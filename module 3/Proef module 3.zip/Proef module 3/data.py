BEDANKT_EN_TOT_ZIENS = 'Bedankt en tot ziens'
SORRY_IK_BEGRIJP_HET_NIET = 'Sorry ik begrijp het niet'
U_MOET_WEL_EEN_GETAL_BOVEN_DE_0_INVOEREN = 'U moet wel een getal boven de 0 invoeren'
SORRY_ZULKE_GROOTTE_BAKJES_VERKOPEN_WIJ_NIET = 'Sorry , zulke grote bakken hebben we niet'

PRIJS_PER_BOLLETJES = 1.10
HOORNTJE = 1.25
BAKJES = 0.75

bestellingen_lijst = []

bestelling_count = 0
bestelling_string = f'bestelling {bestelling_count}'
bestelling = {}
