
#eerste berekening
def addition (nr1 , nr2):
    uitkomst = nr1 + nr2
    return uitkomst 

def substraction (nr1 , nr2):
    uitkomst = nr1 - nr2
    return uitkomst

def multiplication (nr1 , nr2):
    uitkomst = nr1 * nr2
    return uitkomst

def division (nr1 , nr2):
    uitkomst = nr1 / nr2
    return uitkomst


#tweede berekening
def second_addition (uitkomst , nr2):
    uitkomst_1 = uitkomst + nr2
    return uitkomst_1

def second_substraction (uitkomst , nr2):
    uitkomst_1 = uitkomst - nr2
    return uitkomst_1

def second_multiplication (uitkomst , nr2):
    uitkomst_1 = uitkomst * nr2
    return uitkomst_1

def second_division (uitkomst , nr2):
    uitkomst_1 = uitkomst / nr2
    return uitkomst_1
