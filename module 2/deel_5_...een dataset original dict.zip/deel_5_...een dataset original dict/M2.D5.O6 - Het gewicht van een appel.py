from fruitmand import *

for x in fruitmand: 
    if x['name'] =='appel':   
        print(f"De appel weegt {x['weight']} Gram")