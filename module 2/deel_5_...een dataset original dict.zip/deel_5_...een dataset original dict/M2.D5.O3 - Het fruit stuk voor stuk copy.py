from fruitmand import *

for i in fruitmand:
    print(i['name'])
