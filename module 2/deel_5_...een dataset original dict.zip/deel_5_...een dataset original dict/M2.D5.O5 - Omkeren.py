from fruitmand import *

fruitmand.reverse()
for i in fruitmand:
    print(i['name'])