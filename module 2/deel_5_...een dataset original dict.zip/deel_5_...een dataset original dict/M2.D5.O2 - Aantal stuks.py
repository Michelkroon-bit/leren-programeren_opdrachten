from fruitmand import *

count = 0
for i in fruitmand:
    count +=1
print(f'Totaal aantal stukken fruit: {count}')
