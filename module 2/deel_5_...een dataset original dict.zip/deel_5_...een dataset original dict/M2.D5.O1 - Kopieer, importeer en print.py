from fruitmand import *

print(fruitmand)

    