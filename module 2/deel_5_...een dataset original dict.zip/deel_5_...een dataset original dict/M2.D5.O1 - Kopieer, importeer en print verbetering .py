from fruitmand import *

print("rommelige lijst:")
print(fruitmand)
print("")
print("")
# for extra 

print("zelfde lijst maar dan geordend:")
for x in fruitmand:
    print(x)
    