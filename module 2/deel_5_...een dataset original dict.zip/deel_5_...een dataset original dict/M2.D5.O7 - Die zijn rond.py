from fruitmand import *

for x in fruitmand: 
    if x['round'] == True:   
        print(x['name'])